package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Tela4Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela4);

        Button btnMostrar = findViewById(R.id.btnMostrar);
        TextView txtMost1 = findViewById(R.id.txtMost1);
        TextView txtMost2 = findViewById(R.id.txtMost2);
        TextView txtMost3 = findViewById(R.id.txtMost3);
        EditText B = findViewById(R.id.edB);
        EditText C = findViewById(R.id.edC);
        EditText A = findViewById(R.id.edA);

        btnMostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Integer varB = Integer.getInteger(String.valueOf(R.id.edB));
                Integer varC = Integer.getInteger(String.valueOf(R.id.edC));
                Integer varA = Integer.getInteger(String.valueOf(R.id.edA));


                Integer x = Math.sqrt(varB);
                Integer varCalculo1(x-4*varA*varC);
                String mensagem = varCalculo1.toString();

                Integer v = Math.sqrt(varCalculo1);
                Integer varCalculo2(varB+v/varA));
                String mensagem2 = varCalculo2.toString();

                Integer y = Math.sqrt(VarA);
                Integer varCalculo3(varB-v/y));
                String mensagem3 = varCalculo3.toString();


                txtMost1.setText(mensagem);
                txtMost2.setText(mensagem2);
                txtMost3.setText(mensagem3);





        });
    }
}