package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Tela2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);

        Button btnToast = findViewById(R.id.btnToast);
        TextView txtResultado = findViewById(R.id.txtResultado);



        btnToast.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 Integer Valor1 = Integer.getInteger(String.valueOf(R.id.Valor1));
                 Integer Valor2 = Integer.getInteger(String.valueOf(R.id.Valor2));
                 Integer Valor3 = Integer.getInteger(String.valueOf(R.id.Valor3));
                 Integer soma = Valor1+Valor2+Valor3;

                 txtResultado.setText(soma);


             }
         });

    }
}