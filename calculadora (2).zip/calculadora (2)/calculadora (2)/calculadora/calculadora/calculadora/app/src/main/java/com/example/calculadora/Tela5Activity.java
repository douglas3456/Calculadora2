package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Tela5Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela5);

        Button btnTerminou = findViewById(R.id.btnTerminou);
        EditText Nome = findViewById(R.id.edP1);

        EditText Sobrenome = findViewById(R.id.edP2);




        // para levar para proxima tela
        btnTerminou.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String str = Nome.getText().toString();
                String lol = Sobrenome.getText().toString();
                Intent intent = new Intent(getApplicationContext(),Finalizando.class);
                intent.putExtra("nome",str);
                intent.putExtra("sobrenome",lol);


                startActivity(intent);
            }
        });
    }
}