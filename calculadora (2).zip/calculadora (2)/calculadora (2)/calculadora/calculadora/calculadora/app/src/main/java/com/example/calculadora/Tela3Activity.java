package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Tela3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela3);

        // declaracoes dos componentes
        Button btnMostrar = findViewById(R.id.btnMostrar);
        TextView txtMostrar = findViewById(R.id.txtMostrar);
        EditText Nome = findViewById(R.id.edNome);
        EditText Anos = findViewById(R.id.edAnos);
        EditText cm = findViewById(R.id.EdCm);
        EditText Kg = findViewById(R.id.Edkg);

        btnMostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Integer varIdade = Integer.getInteger(String.valueOf(R.id.edAnos));
                Integer varAltura = Integer.getInteger(String.valueOf(R.id.EdCm));
                Integer varPeso = Integer.getInteger(String.valueOf(R.id.Edkg));
                //String varUsuario = getText(String.valueOf(R.id.edNome).toString());
                Integer varNome=Integer.getInteger(String.valueOf(R.id.edNome));


                Integer varCalculo = ( varAltura*2 + varPeso*2);
                String mensagem = varCalculo.toString();


                //Resultadoscal
                txtMostrar.setText(mensagem+""+varCalculo+""+varIdade+""+varNome);


            }
        });
        
        
    }
}