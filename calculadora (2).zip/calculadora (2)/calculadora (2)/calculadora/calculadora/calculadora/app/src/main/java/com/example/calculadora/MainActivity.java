package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnCalculoS = findViewById(R.id.btnCalculoS);
        btnCalculoS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent tela2 = new Intent(getApplicationContext(),Tela2Activity.class);
                startActivity(tela2);



            }
        });
        Button btnImc = findViewById(R.id.btnImc);
        btnImc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            Intent tela3 = new Intent(getApplicationContext(),Tela3Activity.class);
            startActivity(tela3);
            }
        });
        Button btnBas = findViewById(R.id.btnBas);
        btnBas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent tela4 = new Intent(getApplicationContext(),Tela4Activity.class);
                startActivity(tela4);

            }
        });
   Button btn4 = findViewById(R.id.btn4);
   btn4.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View view) {
           Intent tela5 = new Intent(getApplicationContext(),Tela5Activity.class);
           startActivity(tela5);



       }
   });
    }


}