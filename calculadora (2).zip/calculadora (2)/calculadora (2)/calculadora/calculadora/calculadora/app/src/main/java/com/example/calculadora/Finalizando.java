package com.example.calculadora;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Finalizando extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finalizando);


       TextView txtNomeC=findViewById(R.id.txtNomeC);


       String str= getIntent().getStringExtra("Nome");
       String lol = getIntent().getStringExtra("Sobrenome");

       txtNomeC.setText(str+lol);











    }
}